// Copyright 2010 Google Inc. All Rights Reserved.

package com.google.api.data.maps.v2;

public final class Maps {

  public static final String AUTH_TOKEN_TYPE = "local";

  public static final String VERSION = "2";

}
