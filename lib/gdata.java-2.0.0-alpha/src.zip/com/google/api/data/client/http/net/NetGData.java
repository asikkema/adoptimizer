// Copyright 2010 Google Inc. All Rights Reserved.

package com.google.api.data.client.http.net;

public final class NetGData {
  public static final NetHttpTransport HTTP_TRANSPORT = new NetHttpTransport();
}
