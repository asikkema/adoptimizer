// Copyright 2010 Google Inc. All Rights Reserved.

package com.google.api.data.client.http.apache;

public class ApacheGData {
  public static final ApacheHttpTransport HTTP_TRANSPORT =
      new ApacheHttpTransport();
}
