// Copyright 2010 Google Inc. All Rights Reserved.

package com.google.api.data.youtube.v2;

public final class YouTube {

  public static final String AUTH_TOKEN_TYPE = "youtube";

  public static final String VERSION = "2";

}
